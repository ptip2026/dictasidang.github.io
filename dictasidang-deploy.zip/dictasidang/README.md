# 📋 PANDUAN INSTALASI DICTASIDANG di SUBDOMAIN
## Pengadilan Negeri Jakarta Selatan

---

## 📦 ISI PAKET

```
dictasidang/
├── public_html/
│   ├── index.html      ← Aplikasi utama (salin ke server)
│   └── .htaccess       ← Konfigurasi Apache/cPanel
├── nginx.conf          ← Konfigurasi Nginx (jika pakai Nginx)
└── README.md           ← Panduan ini
```

---

## 🚀 CARA 1: cPanel (Shared Hosting / VPS dengan cPanel)

### Langkah-langkah:

1. **Login ke cPanel** hosting Anda

2. **Buat Subdomain:**
   - Masuk ke menu **Domains → Subdomains**
   - Isi: `dictasidang` → Domain: `pnjaksel.go.id`
   - Document Root otomatis: `public_html/dictasidang`
   - Klik **Create**

3. **Upload file:**
   - Buka **File Manager**
   - Navigasi ke folder: `public_html/dictasidang/`
   - Upload file `index.html` dan `.htaccess` (dari folder `public_html/`)
   - **Pastikan `.htaccess` ikut ter-upload** (file tersembunyi)

4. **Akses aplikasi:**
   ```
   https://dictasidang.pnjaksel.go.id
   ```

---

## 🚀 CARA 2: VPS / Server Linux (Nginx)

```bash
# 1. Buat folder
sudo mkdir -p /var/www/dictasidang/public_html

# 2. Upload file ke server (dari komputer lokal)
scp -r public_html/* user@server:/var/www/dictasidang/public_html/

# 3. Copy konfigurasi Nginx
sudo cp nginx.conf /etc/nginx/sites-available/dictasidang.conf
sudo ln -s /etc/nginx/sites-available/dictasidang.conf /etc/nginx/sites-enabled/

# 4. Edit domain di file config (sesuaikan server_name)
sudo nano /etc/nginx/sites-available/dictasidang.conf

# 5. Test & reload Nginx
sudo nginx -t
sudo systemctl reload nginx
```

---

## 🚀 CARA 3: VPS / Server Linux (Apache)

```bash
# 1. Buat folder
sudo mkdir -p /var/www/dictasidang/public_html

# 2. Upload file
sudo cp public_html/index.html /var/www/dictasidang/public_html/
sudo cp public_html/.htaccess  /var/www/dictasidang/public_html/

# 3. Buat Virtual Host Apache
sudo nano /etc/apache2/sites-available/dictasidang.conf
```

Isi dengan:
```apache
<VirtualHost *:80>
    ServerName dictasidang.pnjaksel.go.id
    DocumentRoot /var/www/dictasidang/public_html
    <Directory /var/www/dictasidang/public_html>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

```bash
# 4. Aktifkan site & reload
sudo a2ensite dictasidang.conf
sudo a2enmod rewrite headers expires deflate
sudo systemctl reload apache2
```

---

## 🔒 PASANG SSL (HTTPS) — WAJIB untuk Speech Recognition

Speech Recognition browser **hanya bekerja di HTTPS**. Gunakan Let's Encrypt (gratis):

### Untuk Nginx:
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d dictasidang.pnjaksel.go.id
```

### Untuk Apache:
```bash
sudo apt install certbot python3-certbot-apache
sudo certbot --apache -d dictasidang.pnjaksel.go.id
```

### Untuk cPanel:
- Masuk ke **SSL/TLS → Let's Encrypt**
- Pilih subdomain `dictasidang.pnjaksel.go.id`
- Klik **Issue Certificate**

---

## 🌐 PERSYARATAN BROWSER

| Browser | Speech Recognition | Keterangan |
|---------|-------------------|------------|
| ✅ Google Chrome | Ya | **Direkomendasikan** |
| ✅ Microsoft Edge | Ya | Didukung |
| ❌ Firefox | Tidak | Tidak didukung |
| ❌ Safari | Terbatas | Tidak stabil |

> **Penting:** Buka aplikasi di Chrome untuk hasil terbaik.

---

## ⚙️ PENGATURAN DNS

Tambahkan DNS record di panel domain Anda:

```
Tipe: A
Nama: dictasidang
Nilai: [IP Server Anda]
TTL: 3600
```

---

## 🛠️ TROUBLESHOOTING

| Masalah | Solusi |
|---------|--------|
| Mikrofon tidak bisa diakses | Pastikan HTTPS aktif & izinkan mikrofon di browser |
| Halaman tidak terbuka | Periksa DNS sudah propagasi (cek di dnschecker.org) |
| Speech tidak terdeteksi | Gunakan Chrome, pastikan bahasa Indonesia dipilih |
| History hilang | Jangan hapus cache browser; data tersimpan di localStorage |
| `.htaccess` tidak berfungsi | Pastikan `AllowOverride All` aktif di Apache |

---

## 📞 KONTAK TEKNIS

Aplikasi: **DICTASIDANG V8**  
Instansi: Pengadilan Negeri Jakarta Selatan  
Unit: PTIP (Pengelola Teknologi Informasi dan Pengadilan)  
© PTIP 2026 — Hak Cipta Dilindungi Undang-Undang
